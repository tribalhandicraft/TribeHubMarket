import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { Product, CartItem, Order, User, Language, UserRole, ShippingDetails, PaymentMethod, Review } from '../types';
import { MOCK_PRODUCTS, TRANSLATIONS } from '../constants';

interface SystemSettings {
  maintenanceMode: boolean;
  allowGuestCheckout: boolean;
  platformFee: number;
  contactEmail: string;
}

interface StoreContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  user: User | null;
  login: (role: UserRole, userData?: Partial<User>) => void;
  loginWithPassword: (username: string, pass: string) => { success: boolean; message?: string };
  logout: () => void;
  products: Product[];
  addProduct: (product: Product) => void;
  deleteProduct: (productId: string) => void;
  cart: CartItem[];
  addToCart: (product: Product) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
  orders: Order[];
  placeOrder: (shippingDetails: ShippingDetails, paymentMethod: PaymentMethod) => void;
  cancelOrder: (orderId: string) => void;
  updateOrderStatus: (orderId: string, status: Order['status']) => void;
  addReview: (productId: string, review: Review) => void;
  registerTeamMember: (data: Partial<User>) => void;
  verifyTeamMember: (id: string) => void;
  approveArtisan: (id: string) => void;
  deleteArtisan: (id: string) => void;
  requestPasswordReset: (email: string) => { success: boolean; message: string };
  teamMembers: User[];
  customers: User[];
  deleteUser: (userId: string) => void;
  systemSettings: SystemSettings;
  updateSystemSettings: (settings: Partial<SystemSettings>) => void;
  t: (key: string) => string;
  artisans: User[]; 
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export const StoreProvider = ({ children }: { children?: ReactNode }) => {
  const [language, setLanguage] = useState<Language>('en');
  const [user, setUser] = useState<User | null>(null);
  const [products, setProducts] = useState<Product[]>(MOCK_PRODUCTS);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [systemSettings, setSystemSettings] = useState<SystemSettings>({
    maintenanceMode: false,
    allowGuestCheckout: true,
    platformFee: 5.0,
    contactEmail: 'support@tribalheritage.com'
  });
  
  const adminUser: User = {
      id: 'host1',
      name: 'Super Admin',
      role: 'admin',
      username: 'TRIBALARTHUB',
      password: 'Tribe@123', 
      email: 'admin@tribalheritage.com',
      isVerified: true
  };

  const [teamMembers, setTeamMembers] = useState<User[]>([]);
  const [customers, setCustomers] = useState<User[]>([
    { id: 'c1', name: 'Priya Sharma', role: 'customer', email: 'priya@example.com', contact: '9822334455', location: 'Pune' },
    { id: 'c2', name: 'Rahul Verma', role: 'customer', email: 'rahul@example.com', contact: '9822334466', location: 'Delhi' }
  ]);

  const [artisans, setArtisans] = useState<User[]>([
    { id: 'a1', name: 'Ramesh Kumar', role: 'producer', shopName: 'Ramesh Tribal Arts', location: 'Bastar, Chhattisgarh', artType: 'Dhokra Art', contact: '9876543210', isVerified: true },
    { id: 'a2', name: 'Sita Devi', role: 'producer', shopName: 'Mithila Colors', location: 'Madhubani, Bihar', artType: 'Madhubani Painting', contact: '9876543211', isVerified: true },
    { id: 'a3', name: 'Arjun Singh', role: 'producer', shopName: 'Bamboo Crafts', location: 'Guwahati, Assam', artType: 'Bamboo Handicrafts', contact: '9876543212', isVerified: true }
  ]);

  const t = (key: string): string => TRANSLATIONS[key]?.[language] || key;

  const login = (role: UserRole, userData?: Partial<User>) => {
    const isRegistration = userData && Object.keys(userData).length > 0;
    let userId = userData?.id || (isRegistration ? `u-${Date.now()}` : (role === 'producer' ? 's1' : 'c1'));

    const newUser: User = {
      id: userId,
      name: userData?.name || (role === 'producer' ? 'Ramesh Artisan' : 'Priya Sharma'),
      role: role,
      ...userData,
      isVerified: isRegistration && role === 'producer' ? false : (userData?.isVerified ?? true)
    };
    
    if (newUser.role === 'admin' && newUser.username !== adminUser.username) newUser.role = 'customer';
    setUser(newUser);

    if (role === 'producer' && isRegistration) {
      setArtisans(prev => prev.some(a => a.contact === newUser.contact) ? prev : [newUser, ...prev]);
    } else if (role === 'customer' && isRegistration) {
      setCustomers(prev => [...prev, newUser]);
    }
  };

  const loginWithPassword = (username: string, pass: string) => {
    if (username === adminUser.username && pass === adminUser.password) {
        setUser(adminUser);
        return { success: true };
    }
    const teamMember = teamMembers.find(tm => tm.username === username && tm.password === pass);
    if (teamMember) {
        if (!teamMember.isVerified) return { success: false, message: 'accountPending' };
        setUser(teamMember);
        return { success: true };
    }
    return { success: false, message: 'invalidCredentials' };
  };

  const updateSystemSettings = (settings: Partial<SystemSettings>) => {
    setSystemSettings(prev => ({ ...prev, ...settings }));
  };

  const deleteUser = (userId: string) => {
    setCustomers(prev => prev.filter(u => u.id !== userId));
    setArtisans(prev => prev.filter(u => u.id !== userId));
    setTeamMembers(prev => prev.filter(u => u.id !== userId));
  };

  const requestPasswordReset = (email: string) => {
      if (email.toLowerCase() === adminUser.email?.toLowerCase()) return { success: true, message: 'resetEmailSent' };
      if (teamMembers.find(m => m.email?.toLowerCase() === email.toLowerCase())) return { success: true, message: 'resetEmailSent' };
      return { success: false, message: 'emailNotFound' };
  };

  const registerTeamMember = (data: Partial<User>) => {
      const newUser: User = {
          id: `tm-${Date.now()}`,
          name: data.name || 'Team Member',
          role: 'team_member',
          isVerified: false,
          ...data
      };
      setTeamMembers(prev => [...prev, newUser]);
  };

  const verifyTeamMember = (id: string) => setTeamMembers(prev => prev.map(m => m.id === id ? { ...m, isVerified: true } : m));
  const approveArtisan = (id: string) => setArtisans(prev => prev.map(a => a.id === id ? { ...a, isVerified: true } : a));
  const deleteArtisan = (id: string) => {
    setArtisans(prev => prev.filter(a => a.id !== id));
    setProducts(prev => prev.filter(p => p.sellerId !== id));
  };

  const logout = () => { setUser(null); setCart([]); };
  const addProduct = (product: Product) => setProducts((prev) => [product, ...prev]);
  const deleteProduct = (productId: string) => setProducts((prev) => prev.filter(p => p.id !== productId));
  const addToCart = (product: Product) => {
    setCart((prev) => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      return [...prev, { ...product, quantity: 1 }];
    });
  };
  const removeFromCart = (productId: string) => setCart(prev => prev.filter(item => item.id !== productId));
  const clearCart = () => setCart([]);

  const placeOrder = (shippingDetails: ShippingDetails, paymentMethod: PaymentMethod) => {
    if (!user || cart.length === 0) return;
    const newOrder: Order = {
      id: `ORD-${Date.now()}`,
      customerId: user.id,
      items: [...cart],
      total: cart.reduce((sum, item) => sum + (item.price * item.quantity), 0),
      status: 'pending',
      date: new Date().toISOString(),
      shippingDetails,
      paymentMethod
    };
    setOrders(prev => [newOrder, ...prev]);
    clearCart();
  };

  const cancelOrder = (orderId: string) => setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: 'cancelled' } : o));
  const updateOrderStatus = (orderId: string, status: Order['status']) => setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status } : o));
  const addReview = (productId: string, review: Review) => setProducts(prev => prev.map(p => p.id === productId ? { ...p, reviews: [review, ...p.reviews] } : p));

  return (
    <StoreContext.Provider value={{
      language, setLanguage, user, login, loginWithPassword, logout,
      products, addProduct, deleteProduct, cart, addToCart, removeFromCart, clearCart,
      orders, placeOrder, cancelOrder, updateOrderStatus, addReview,
      registerTeamMember, verifyTeamMember, approveArtisan, deleteArtisan,
      requestPasswordReset, teamMembers, customers, deleteUser,
      systemSettings, updateSystemSettings, t, artisans
    }}>
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) throw new Error("useStore must be used within StoreProvider");
  return context;
};